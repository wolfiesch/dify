"""Tie the measured installed native module and Python sources to an actual PyPI wheel.

python verify_wheel.py <benchmark-or-differential>/results.json
"""
import hashlib
import io
import json
from pathlib import Path
import sys
import urllib.request
import zipfile


def main():
    results_path = Path(sys.argv[1])
    results = json.loads(results_path.read_text())
    env = results['environment']
    tag = 'cp' + ''.join(env['python'].split('.')[:2])
    platform_tag = 'macosx_11_0_arm64' if env['os'] == 'Darwin' else 'manylinux_2_28_x86_64'
    name = f'wolfxl-2.0.17-{tag}-{tag}-{platform_tag}.whl'
    with urllib.request.urlopen('https://pypi.org/pypi/wolfxl/2.0.17/json', timeout=30) as response:
        metadata = json.load(response)
    artifact = next(item for item in metadata['urls'] if item['filename'] == name)
    with urllib.request.urlopen(artifact['url'], timeout=60) as response:
        body = response.read()
    digest = hashlib.sha256(body).hexdigest()
    assert digest == artifact['digests']['sha256']
    compared = []
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        for record in results['packages']['wolfxl']['installed_files']:
            actual = hashlib.sha256(archive.read(record['file'])).hexdigest()
            assert actual == record['sha256'], record['file']
            compared.append(record)
    receipt = {'measured_results_sha256': hashlib.sha256(results_path.read_bytes()).hexdigest(),
               'filename': name, 'url': artifact['url'], 'wheel_sha256': digest,
               'pypi_sha256_matched': True, 'all_measured_source_and_native_hashes_match_wheel': True,
               'compared_files': compared,
               'source_commit': 'unverified: published archive identity is proven, not its upstream Git build provenance'}
    output = results_path.with_name('wheel-provenance.json')
    output.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'filename': name, 'wheel_sha256': digest, 'matched_files': len(compared)}))


if __name__ == '__main__':
    main()
