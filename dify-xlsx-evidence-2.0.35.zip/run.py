"""Rerun the unchanged Dify eager extraction harness using published packages.

uv run --python <interpreter> --with wolfxl==2.0.17 --with openpyxl==3.1.5 \
  --with Pillow==13.0.0 python run.py corpus <POI>/test-data/spreadsheet <output>
uv run --python <interpreter> --with wolfxl==2.0.17 --with openpyxl==3.1.5 \
  --with Pillow==13.0.0 python run.py bench <big300k.xlsx-or-small300.xlsx> <output>
"""
import collections
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import urllib.request

import dify_diff


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(name):
    dist = importlib.metadata.distribution(name)
    records = []
    for file in sorted(dist.files, key=str):
        if file.suffix in ('.py', '.so', '.pyd'):
            path = dist.locate_file(file)
            records.append({'file': str(file), 'sha256': sha(path)})
    digest = hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest()
    with urllib.request.urlopen(f'https://pypi.org/pypi/{name}/{dist.version}/json', timeout=30) as response:
        meta = json.load(response)
    return {'version': dist.version, 'installed_source_and_native_files_sha256': digest,
            'installed_files': records,
            'pypi_release_artifacts': [{'filename': f['filename'], 'sha256': f['digests']['sha256']}
                                       for f in meta['urls']],
            'build_mode': 'published PyPI wheel, no local build, uv cache permitted'}


def outcome(row):
    a, b = row['openpyxl'], row['wolfxl']
    if a['status'] == b['status'] == 'ok':
        return 'same' if all(a[k] == b[k] for k in ('sha', 'docs', 'images')) else 'differ'
    if a['status'] == b['status'] == 'raise':
        return 'both_raise'
    if a['status'] == 'ok':
        return 'openpyxl_ok_wolfxl_' + b['status']
    if b['status'] == 'ok':
        return 'openpyxl_' + a['status'] + '_wolfxl_ok'
    return 'both_failed_or_timed_out'


def main():
    mode, input_arg, output_arg = sys.argv[1:]
    source, out = Path(input_arg).resolve(), Path(output_arg)
    out.mkdir(parents=True, exist_ok=True)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = {'started_utc': start, 'mode': mode,
              'environment': {'os': platform.system(), 'release': platform.release(),
                              'machine': platform.machine(), 'python': platform.python_version(),
                              'interpreter_sha256': sha(sys.executable),
                              'load_average_start': os.getloadavg()},
              'packages': {name: identity(name) for name in ('wolfxl', 'openpyxl', 'Pillow')},
              'harness_sha256': sha(Path(__file__).with_name('dify_diff.py')),
              'run_driver_sha256': sha(__file__),
              'read_path': 'Dify eager load_workbook(path, data_only=True), header scan, hyperlinks and image bytes; storage/database excluded',
              'timeouts': {'per_library_file_seconds': 60 if mode == 'corpus' else 180,
                           'overall_job_seconds': 1800},
              'cache': 'warm page cache, no cache flush; fresh interpreter each library/file or measured run',
              'warmups_discarded': 0, 'source_identity': 'Published PyPI release, installed-file digests and release archive digests recorded; no claim of source commit provenance'}
    if mode == 'corpus':
        files = sorted(source.glob('*.xlsx'))
        result['corpus'] = {'repository': 'apache/poi',
                            'commit': subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip(),
                            'file_count': len(files),
                            'files': [{'file': f.name, 'sha256': sha(f)} for f in files]}
        assert result['corpus']['commit'] == '4f3c25563919e7efa4a75feccf6cef1ac3d05a04'
        assert len(files) == 353
        dify_diff.corpus(str(source), str(out / 'raw.jsonl'))
        rows = [json.loads(line) for line in (out / 'raw.jsonl').read_text().splitlines()]
        for row in rows:
            row['outcome'] = outcome(row)
        result['outcomes'] = dict(collections.Counter(r['outcome'] for r in rows))
        result['rows'] = rows
    elif mode == 'bench':
        sizes = {'big300k.xlsx': 300000, 'small300.xlsx': 300}
        result['input'] = {'file': source.name, 'sha256': sha(source), 'data_rows': sizes[source.name], 'columns': 7}
        if source.name == 'big300k.xlsx':
            assert result['input']['sha256'] == 'af9ebaaa59d525e23183a83b4334ed22b39ba81f7992d9c75a9923c119b65b49'
        result['iterations_per_library'] = 5
        result['timing_scope'] = 'Full extraction loop only; excludes interpreter startup, imports, and output hashing; RSS is process lifetime high-water mark, MiB'
        result['cold_start_metrics'] = 'not measured'
        result['runs'] = []
        # Pre-read the input explicitly so the page-cache statement is reproducible.
        source.read_bytes()
        for iteration in range(1, 6):
            for lib in ('openpyxl', 'wolfxl'):
                command = [sys.executable, str(Path(__file__).with_name('dify_diff.py')), 'bench', lib, str(source)]
                started = time.monotonic()
                try:
                    proc = subprocess.run(command, text=True, capture_output=True, timeout=180)
                    row = {'iteration': iteration, 'exit_code': proc.returncode,
                           'subprocess_wall_seconds': round(time.monotonic()-started, 3)}
                    if proc.returncode == 0:
                        row.update(json.loads(proc.stdout.strip().splitlines()[-1]))
                    else:
                        row.update({'lib': lib, 'status': 'failed', 'stderr': proc.stderr[-2000:]})
                except subprocess.TimeoutExpired:
                    row = {'iteration': iteration, 'lib': lib, 'status': 'timeout', 'timeout_seconds': 180}
                result['runs'].append(row)
                with (out / 'raw.jsonl').open('a') as stream:
                    stream.write(json.dumps(row) + '\n')
        import statistics
        result['summary'] = {}
        for lib in ('openpyxl', 'wolfxl'):
            rows = [r for r in result['runs'] if r['lib'] == lib and r.get('exit_code') == 0]
            result['summary'][lib] = {key: {'median': statistics.median(r[key] for r in rows),
                                           'min': min(r[key] for r in rows), 'max': max(r[key] for r in rows)}
                                       for key in ('seconds', 'peak_rss_mb')} if rows else {}
    else:
        raise SystemExit(mode)
    result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['raw_sha256'] = sha(out/'raw.jsonl')
    result['environment']['load_average_end'] = os.getloadavg()
    (out/'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('started_utc', 'finished_utc', 'outcomes', 'summary') if k in result}))


if __name__ == '__main__':
    main()
