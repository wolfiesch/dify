XLSX reader timing evidence: wolfxl 2.0.35 vs openpyxl 3.1.5 (Pillow 13.0.0)

Same drivers, harness (dify_diff.py, sha256 18c553228f3c...) and inputs as
dify-xlsx-evidence-2.0.17.zip; only the wolfxl pin changed. Both arms were
rerun fresh, alternating openpyxl then wolfxl, five runs each, no discarded
warmup, warm page cache, 180 s per-run and 1800 s overall timeouts.

benchmark-linux-big, benchmark-linux-small
  Linux x86_64, kernel 7.0.0-38-generic, AMD Ryzen 9950X3D (shared host,
  load average 4.0 to 6.1), CPython 3.13.15. Driver: run_rss_safe.py.
  Same host and interpreter as the 2.0.17 Linux run.

benchmark-macos-big, benchmark-macos-small
  macOS arm64, Darwin 25.6.0, Apple M4 Pro 14-core, 24 GB (load average 3.5
  to 4.0), CPython 3.13.9. Driver: run.py. Different host from the 2.0.17
  macOS run (Apple M5 Pro, Darwin 25.5.0); same interpreter build.

discarded-workstation-load
  A first macOS run on the 2.0.17 host while its load average was 11 to 18.
  Kept for completeness; not cited, because run-to-run ranges were wide
  (openpyxl 19.5 to 28.5 s, wolfxl 8.0 to 14.9 s).

Rerun (POSIX shell, from this directory):
  sha256sum -c SHA256SUMS.txt     # macOS: shasum -a 256 -c SHA256SUMS.txt
  UV_NO_BUILD_PACKAGE=wolfxl uv run --no-project --python 3.13.15 \
    --with wolfxl==2.0.35 --with openpyxl==3.1.5 --with Pillow==13.0.0 \
    python run_rss_safe.py bench big300k.xlsx out-linux-big
Use run.py and Python 3.13.9 on macOS, small300.xlsx for the small case, and
a fresh output directory each time. Expected output identity: 300,000
documents with text hash prefix 33bcefba97527c1a (big), 300 documents with
ff18ac2b8b8ea16c (small).
