XLSX reader evidence: wolfxl 2.0.35 vs openpyxl 3.1.5 (Pillow 13.0.0)

differential-linux, differential-macos (corpus)
  The 353 .xlsx files in apache/poi test-data/spreadsheet at commit
  4f3c25563919e7efa4a75feccf6cef1ac3d05a04, each read through the harness by
  each library in a fresh child process with a 60 s timeout. Same hosts and
  interpreters as the 2.0.17 corpus run: Linux CPython 3.12.14 (run_rss_safe.py),
  macOS arm64 Darwin 25.5.0 CPython 3.13.9 (run.py).
  Result: per-file status, text hash, document count and image count are
  identical to 2.0.17 for both libraries on all 353 files, except
  poc-shared-strings.xlsx on macOS, which ended as timeout under both libraries
  instead of crash (SIGKILL) under both.
  Outcomes on each platform: same 312, differ 5, both raise 30,
  openpyxl raise / wolfxl ok 4, openpyxl ok / wolfxl raise 1, both failed 1.
  The Linux run was confined to an 8 GiB memory cgroup so the
  poc-shared-strings.xlsx memory bomb is killed inside the job; nothing else
  reached the cap. Absolute checkout prefixes in error strings were replaced
  with "poi/" after the run, so raw_sha256 in results.json describes the file
  before that replacement.

Timing evidence (benchmark-*):

Same drivers, harness (dify_diff.py, sha256 18c553228f3c...) and inputs as
dify-xlsx-evidence-2.0.17.zip; only the wolfxl pin changed. Both arms were
rerun fresh, alternating openpyxl then wolfxl, five runs each, no discarded
warmup, warm page cache, 180 s per-run and 1800 s overall timeouts.

benchmark-linux-big, benchmark-linux-small
  Linux x86_64, kernel 7.0.0-38-generic, AMD Ryzen 9950X3D (shared host,
  load average 4.0 to 6.1), CPython 3.13.15. Driver: run_rss_safe.py.
  Same host and interpreter as the 2.0.17 Linux run.

benchmark-macos-big, benchmark-macos-small
  macOS arm64, Darwin 25.6.0, Apple M4 Pro 14-core, 24 GB (load average 3.5
  to 4.0), CPython 3.13.9. Driver: run.py. Different host from the 2.0.17
  macOS run (Apple M5 Pro, Darwin 25.5.0); same interpreter build.

discarded-workstation-load
  A first macOS run on the 2.0.17 host while its load average was 11 to 18.
  Kept for completeness; not cited, because run-to-run ranges were wide
  (openpyxl 19.5 to 28.5 s, wolfxl 8.0 to 14.9 s).

Rerun (POSIX shell, from this directory):
  sha256sum -c SHA256SUMS.txt     # macOS: shasum -a 256 -c SHA256SUMS.txt
  UV_NO_BUILD_PACKAGE=wolfxl uv run --no-project --python 3.13.15 \
    --with wolfxl==2.0.35 --with openpyxl==3.1.5 --with Pillow==13.0.0 \
    python run_rss_safe.py bench big300k.xlsx out-linux-big
Use run.py and Python 3.13.9 on macOS, small300.xlsx for the small case, and
a fresh output directory each time. Expected output identity: 300,000
documents with text hash prefix 33bcefba97527c1a (big), 300 documents with
ff18ac2b8b8ea16c (small).
