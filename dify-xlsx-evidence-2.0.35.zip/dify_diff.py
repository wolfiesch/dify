"""Dify ExcelExtractor (.xlsx branch) read path, openpyxl vs wolfxl.

Mirrors api/core/rag/extractor/excel_extractor.py at langgenius/dify 5c510d0737:
extract(), _find_header_and_columns() and _extract_images_from_sheet() with the
storage/DB step replaced by a content-hash placeholder, so image extraction is compared too.

  python dify_diff.py one <lib> <file>            -> one JSON line
  python dify_diff.py corpus <dir> <out.jsonl>    -> child process per file and library, 60 s timeout
  python dify_diff.py bench <lib> <file>          -> wall seconds and peak RSS
"""

import hashlib
import json
import os
import resource
import subprocess
import sys
import time


def find_header_and_columns(sheet, scan_rows=10):
    candidates = []
    for current_row_idx, row in enumerate(sheet.iter_rows(min_row=1, max_row=scan_rows, values_only=True), start=1):
        row_map = {}
        for col_idx, cell_value in enumerate(row):
            if cell_value is not None and str(cell_value).strip():
                row_map[col_idx] = str(cell_value).strip().replace('"', '\\"')
        if not row_map:
            continue
        candidates.append({"idx": current_row_idx, "count": len(row_map), "map": row_map})
    if not candidates:
        return 0, {}, 0
    best = None
    for cand in candidates:
        if cand["count"] >= 2:
            best = cand
            break
    if not best:
        candidates.sort(key=lambda x: (-x["count"], x["idx"]))
        best = candidates[0]
    return best["idx"], best["map"], max(best["map"].keys()) + 1


def image_bytes(image):
    loader = getattr(image, "_data", None)
    if not callable(loader):
        return None
    try:
        data = loader()
    except Exception:
        return None
    return bytes(data) if isinstance(data, (bytes, bytearray)) else None


def image_ext(image):
    fmt = getattr(image, "format", None)
    if isinstance(fmt, str) and fmt.strip():
        return fmt.strip().lower()
    path = getattr(image, "path", None)
    if isinstance(path, str):
        ext = os.path.splitext(path)[1]
        if ext:
            return ext.lstrip(".").lower()
    return None


def images_from_sheet(sheet, valid_columns, min_row):
    image_map = {}
    for image in getattr(sheet, "_images", None) or []:
        marker = getattr(getattr(image, "anchor", None), "_from", None)
        row_idx, col_idx = getattr(marker, "row", None), getattr(marker, "col", None)
        if row_idx is None or col_idx is None:
            continue
        if row_idx + 1 < min_row or col_idx + 1 not in valid_columns:
            continue
        data = image_bytes(image)
        ext = image_ext(image) if data else None
        if not data or not ext:
            continue
        digest = hashlib.sha256(data).hexdigest()[:16]
        image_map.setdefault((row_idx + 1, col_idx + 1), []).append(f"![image]({digest}.{ext})")
    return image_map


def extract(load_workbook, path):
    documents, images = [], 0
    wb = load_workbook(path, data_only=True)
    try:
        for sheet_name in wb.sheetnames:
            sheet = wb[sheet_name]
            header_row_idx, column_map, max_col_idx = find_header_and_columns(sheet)
            if not column_map:
                continue
            start_row = header_row_idx + 1
            sheet_image_map = images_from_sheet(sheet, {c + 1 for c in column_map}, start_row)
            images += sum(len(v) for v in sheet_image_map.values())
            for row in sheet.iter_rows(min_row=start_row, max_col=max_col_idx, values_only=False):
                page_content, row_has_content = [], False
                for col_idx, cell in enumerate(row):
                    value = cell.value
                    if col_idx in column_map:
                        col_name = column_map[col_idx]
                        if hasattr(cell, "hyperlink") and cell.hyperlink:
                            target = getattr(cell.hyperlink, "target", None)
                            if target:
                                display = value if value is not None and str(value).strip() else target
                                value = f"[{display}]({target})"
                        cell_row, cell_column = getattr(cell, "row", None), getattr(cell, "column", None)
                        links = (
                            sheet_image_map.get((cell_row, cell_column), [])
                            if isinstance(cell_row, int) and isinstance(cell_column, int)
                            else []
                        )
                        if value is None:
                            value = ""
                        elif not isinstance(value, str):
                            value = str(value)
                        if links:
                            value = " ".join(filter(None, [value, " ".join(links)]))
                        value = value.strip()
                        if value:
                            row_has_content = True
                        value = value.replace('"', '\\"')
                        page_content.append(f'"{col_name}":"{value}"')
                if row_has_content and page_content:
                    documents.append(";".join(page_content))
    finally:
        wb.close()
    return documents, images


def loader(lib):
    if lib == "openpyxl":
        import openpyxl

        return openpyxl.load_workbook, openpyxl.__version__
    import wolfxl

    return wolfxl.load_workbook, wolfxl.__version__


def one(lib, path):
    load, version = loader(lib)
    try:
        docs, images = extract(load, path)
    except Exception as exc:  # Dify lets every exception fail the upload
        return {"status": "raise", "error": f"{type(exc).__name__}: {str(exc)[:160]}", "version": version}
    blob = "\n".join(docs).encode()
    return {
        "status": "ok",
        "sha": hashlib.sha256(blob).hexdigest()[:16],
        "docs": len(docs),
        "images": images,
        "version": version,
    }


def child(lib, path):
    try:
        out = subprocess.run(
            [sys.executable, __file__, "one", lib, path], capture_output=True, text=True, timeout=60
        )
    except subprocess.TimeoutExpired:
        return {"status": "timeout"}
    if out.returncode != 0:
        return {"status": "crash", "rc": out.returncode, "stderr": out.stderr[-200:]}
    return json.loads(out.stdout.strip().splitlines()[-1])


def corpus(root, out_path):
    files = sorted(f for f in os.listdir(root) if f.lower().endswith(".xlsx"))
    with open(out_path, "w") as out:
        for name in files:
            path = os.path.join(root, name)
            row = {"file": name, "openpyxl": child("openpyxl", path), "wolfxl": child("wolfxl", path)}
            out.write(json.dumps(row) + "\n")
            out.flush()


def bench(lib, path):
    load, version = loader(lib)
    start = time.perf_counter()
    docs, images = extract(load, path)
    seconds = time.perf_counter() - start
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    rss_mb = rss / (1024 * 1024) if sys.platform == "darwin" else rss / 1024
    blob = "\n".join(docs).encode()
    print(json.dumps({
        "lib": lib, "version": version, "seconds": round(seconds, 3), "peak_rss_mb": round(rss_mb, 1),
        "docs": len(docs), "images": images, "sha": hashlib.sha256(blob).hexdigest()[:16],
    }))


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "one":
        print(json.dumps(one(sys.argv[2], sys.argv[3])))
    elif mode == "corpus":
        corpus(sys.argv[2], sys.argv[3])
    elif mode == "bench":
        bench(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit(f"unknown mode {mode}")
