"""Generate small300.xlsx from the header and first 300 data rows of big300k.xlsx.

Run with openpyxl 3.1.5: python make_small.py <big300k.xlsx> <small300.xlsx>
This is a typical-sized synthetic slice, not a real customer workbook.
"""
import hashlib
import json
from pathlib import Path
import sys

import openpyxl

source, destination = map(Path, sys.argv[1:])
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'af9ebaaa59d525e23183a83b4334ed22b39ba81f7992d9c75a9923c119b65b49'
original = openpyxl.load_workbook(source, read_only=True, data_only=True)
small = openpyxl.Workbook(write_only=True)
sheet = small.create_sheet('Sheet')
for row in original.active.iter_rows(min_row=1, max_row=301, max_col=7, values_only=True):
    sheet.append(row)
small.save(destination)
original.close()
print(json.dumps({'file': destination.name, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'data_rows': 300, 'columns': 7, 'source': source.name, 'openpyxl': openpyxl.__version__}))
